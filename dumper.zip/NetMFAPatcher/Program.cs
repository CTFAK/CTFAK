﻿using NetMFAPatcher.Chunks;
using NetMFAPatcher.Utils;
using NetMFAPatcher.mmfparser;
using System;
using System.IO;
using System.Collections;

namespace NetMFAPatcher
{
    class Program
    {
        public static PackData pack_data;
        public static GameData game_data;
        //public static string path = @"H:\fnaf-world.exe";
        public static string path = @"E:\Games\sl\SisterLocation.exe";
        //public static string path = @"H:\SteamLibrary\steamapps\common\Freddy Fazbear's Pizzeria Simulator\Pizzeria Simulator.exe";

        public static string filename = Path.GetFileNameWithoutExtension(path);

        [STAThread]
        static void Main(string[] args)
        {

            ByteIO exeReader = new ByteIO(path, FileMode.Open);
            PrepareFolders();
            ParseExe(exeReader);



            Logger.Log("Finished!", true, ConsoleColor.Yellow);
            Console.ReadKey();
        }

        public static void PrepareFolders()
        {
            Directory.CreateDirectory($"DUMP\\{filename}\\CHUNKS\\OBJECTINFO");
            Directory.CreateDirectory($"DUMP\\{filename}\\CHUNKS\\FRAMES");
            Directory.CreateDirectory($"DUMP\\{filename}\\ImageBank");
            Directory.CreateDirectory($"DUMP\\{filename}\\MusicBank");
            Directory.CreateDirectory($"DUMP\\{filename}\\SoundBank");
            Directory.CreateDirectory($"DUMP\\{filename}\\extensions");
        }



        public static void ParseExe(ByteIO exeReader)
        {

            //Console.WriteLine();
            Logger.Log($"Executable: {Path.GetFileName(path)}\n",true,ConsoleColor.DarkRed);
            var es = exeReader.ReadAscii(2);
            Logger.Log("EXE Header: " + es, true, ConsoleColor.Yellow);
            //Console.WriteLine();
            if (es != "MZ")
            {
                Console.WriteLine("Invalid executable signature");
            }

            
            exeReader.Seek(60,SeekOrigin.Begin);

            UInt16 hdr_offset = exeReader.ReadUInt16();


            exeReader.Seek(hdr_offset, SeekOrigin.Begin);
            string peHdr = exeReader.ReadAscii(2);
            Logger.Log("PE Header: " + peHdr, true, ConsoleColor.Yellow);
            exeReader.Skip(4);

            UInt16 num_of_sections = exeReader.ReadUInt16();

            exeReader.Skip(16);
            var optional_header = 28 + 68;
            var data_dir = 16 * 8;
            exeReader.Skip(optional_header + data_dir);

            uint possition = 0;
            for (int i = 0; i < num_of_sections; i++)
            {
                var entry = exeReader.Tell();

                var section_name = exeReader.ReadAscii();

                if (section_name == ".extra")
                {
                    exeReader.Seek(entry + 20);
                    possition = exeReader.ReadUInt32();
                    break;
                }
                else if (i >= num_of_sections - 1)
                {
                    exeReader.Seek(entry + 16);
                    uint size = exeReader.ReadUInt32();
                    uint address = exeReader.ReadUInt32();
                    possition = address + size;
                    break;
                }

                exeReader.Seek(entry + 40);
            }

            exeReader.Seek((int) possition);
            UInt16 first_short = exeReader.PeekUInt16();
            Logger.Log("First Short: " + first_short.ToString("X2"), true, ConsoleColor.Yellow);

            if (first_short == 0x7777)
            {
                Logger.Log("Found PackData header!\nReading PackData header.", true, ConsoleColor.Blue);
                pack_data = new PackData();
                pack_data.Read(exeReader);
                game_data = new GameData();
                game_data.Read(exeReader);
                Console.ForegroundColor = ConsoleColor.DarkGreen;
            }
            else
            {
                Logger.Log("Failed to find PackData header!\n", true, ConsoleColor.Red);
            }
        }
    }
}