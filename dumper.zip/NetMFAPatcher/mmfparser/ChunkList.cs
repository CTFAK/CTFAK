﻿using NetMFAPatcher.Chunks;
using NetMFAPatcher.Utils;

using System;
using System.Collections.Generic;
using System.IO;

using static NetMFAPatcher.Chunks.Constants;

namespace NetMFAPatcher.mmfparser
{
    public class ChunkList
    {
        List<Chunk> chunks = new List<Chunk>();
        public bool verbose = true;

        public void Read(ByteIO exeReader)
        {
            chunks.Clear();
            while (true)
            {
                Chunk chunk = new Chunk(chunks.Count, this);
                chunk.Read(exeReader);              
                chunk.loader = LoadChunk(chunk);

                if (chunk.loader != null) chunk.loader.Print();






                if (verbose)
                {
                    chunk.Print();


                }
                chunks.Add(chunk);
                if (chunk.id == 32639)
                {
                    break;

                }



            }
            //Logger.Log($"Total Chunks Count: {chunks.Count}", true, ConsoleColor.Blue);
        }

        public class Chunk
        {

            ChunkList chunk_list;
            bool verbose = true;
            int uid;
            public int id = 0;
            public string name = "UNKNOWN";
            public ChunkLoader loader;
            public byte[] raw_data;
            public byte[] chunk_data = null;

            public ChunkFlags flag;
            int raw_flag;
            int size = 0;
            int decompressed_size = 0;
            int entry = 0;

            public Chunk(int Actualuid, ChunkList actual_chunk_list)
            {
                uid = Actualuid;
                chunk_list = actual_chunk_list;
            }
            public void Read(ByteIO exeReader)
            {
                id = exeReader.ReadInt16();
                name = ((ChunkNames)id).ToString();

                raw_flag = exeReader.ReadInt16();
                flag = (ChunkFlags)raw_flag;
                size = exeReader.ReadInt32();

                switch (flag)
                {
                    case ChunkFlags.ENCRYPTED:
                        //Decrypt
                        chunk_data = exeReader.ReadBytes(size);
                        break;
                    case ChunkFlags.COMPRESSED_AND_ENCRYPYED:
                        chunk_data = exeReader.ReadBytes(size);
                        break;
                    case ChunkFlags.COMPRESSED:
                        chunk_data = Decompressor.Decompress(exeReader);
                        break;
                    case ChunkFlags.NOT_COMPRESSED:
                        chunk_data = exeReader.ReadBytes(size);
                        break;
                }
                if (chunk_data != null)
                {
                    decompressed_size = chunk_data.Length;
                    string path = $"DUMP\\{Program.filename}\\CHUNKS\\{name}.chunk";
                    File.WriteAllBytes(path, chunk_data);
                }














            }
            public void Print()
            {
                Logger.Log($"Chunk: {name} ({uid})", true, ConsoleColor.DarkCyan);
                Logger.Log($"    ID: {id} - 0x{id.ToString("X")}", true, ConsoleColor.DarkCyan);
                Logger.Log($"    Flags: {(ChunkFlags)raw_flag}", true, ConsoleColor.DarkCyan);
                Logger.Log($"    Loader: {(loader != null ? loader.GetType().Name : "Null")}", true, ConsoleColor.DarkCyan);
                Logger.Log($"    Size: {size} B", true, ConsoleColor.DarkCyan);
                Logger.Log($"    Decompressed Size: {decompressed_size} B", true, ConsoleColor.DarkCyan);
                Logger.Log("---------------------------------------------", true, ConsoleColor.DarkCyan);



            }






        }
        public enum ChunkFlags
        {
            NOT_COMPRESSED = 0,
            COMPRESSED = 1,
            ENCRYPTED = 2,
            COMPRESSED_AND_ENCRYPYED = 3

        }
        public ChunkLoader LoadChunk(Chunk chunk)
        {
            ChunkLoader loader;
            switch (chunk.id)
            {
                
                case 8739:
                    return LoadChunk<AppHeader>(chunk);
                case 8740:
                    return LoadChunk<AppName>(chunk);
                case 8741:
                    return LoadChunk<AppAuthor>(chunk);
                case 8743:
                    return LoadChunk<ExtPath>(chunk);
                case 8750:
                    return LoadChunk<EditorFilename>(chunk);
                case 8751:
                    return LoadChunk<TargetFilename>(chunk);
                case 8752:
                    return LoadChunk<AppDoc>(chunk);
                case 8762:
                    return LoadChunk<AboutText>(chunk);
                case 8763:
                    return LoadChunk<Copyright>(chunk);
                case 13123:
                    return LoadChunk<DemoFilePath>(chunk);
                case 13109:
                    return LoadChunk<FrameName>(chunk);
                case 13107:
                    return LoadChunk<Frame>(chunk);
                case 26214:
                    return null;//LoadChunk<ImageBank>(chunk);
                case 26216:
                    return LoadChunk<SoundBank>(chunk);











            }
            return null;

        }
        
        
        private ChunkLoader LoadChunk<T>(Chunk chunk) where T:ChunkLoader,new()
        {
            ChunkLoader loader;
            loader = new T();
            loader.chunk = chunk;
            loader.Read();
            return loader;


        }
        public T get_chunk<T>() where T:ChunkLoader
        {
            foreach(var chunk in chunks)
            {
                if (chunk.loader != null)
                {


                    if (chunk.loader.GetType().Name == typeof(T).Name)
                    {
                        return (T)chunk.loader;

                    }
                }
            }
            return null; //I hope this wont happen  
        }
        
    }
}
